
public class Main {
    public static void main(String[] args) {
        School Uhill = new School(1970, "your mom",2000);
        Uhill.addStudent("benzino",10);
        Uhill.addStudent("Veronica", "fisher",12)
        Uhill.addteacher("Hailey kim", "Science");
        System.out.println(Uhill.showTeachers());
        Uhill.delteacher("Hailey kim");
        System.out.println(Uhill.showStudents());


    }
}
